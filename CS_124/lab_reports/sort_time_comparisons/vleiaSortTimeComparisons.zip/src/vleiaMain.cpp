#include <iostream>
#include <fstream>
#include <string>

#include "vleiaTextFileNames.h"
#include "vleiaDelimeters.h"
#include "vleiaSortingLib.h"
#include "vleiaFileManip.h"
#include "vleiaCreateMenu.h"

using std::cout;
using std::endl;
using std::fstream;


int main(){

	vleiaCreateMenu mo;

	return 0;
}