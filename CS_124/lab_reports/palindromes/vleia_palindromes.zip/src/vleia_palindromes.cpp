/*
  author: Tino Lei'a
  program name: Palindromes
  description: lets the user choose to either input their
  			   own string or choose between 2 files to test
  			   for palindromes. They can also choose to 
  			   save the palindromes to their own text file.
  date authored: Fall 2020
*/

// needed library and header files
#include <iostream>
#include "vleia_userInterface.h"


	// driver code
	int main(){
		
		// create object of userInterface to run the program
		userInterface uiObject;

		return 0;
	}