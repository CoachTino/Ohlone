#ifndef LISTNODE_H
#define LISTNODE_H

	struct ListNode{
		
		// to hold palindromes
		std::string data;
		
		// pointer to next node
		struct ListNode *next;

	};

#endif 